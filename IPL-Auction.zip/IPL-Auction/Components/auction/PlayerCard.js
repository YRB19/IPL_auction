import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Trophy, Activity, BarChart2 } from 'lucide-react';

export default function PlayerCard({ player, currentPrice, winner, status }) {
  if (!player) return (
    <Card className="h-full flex items-center justify-center bg-slate-50 border-dashed">
      <div className="text-center text-slate-400">
        <User className="w-16 h-16 mx-auto mb-4 opacity-20" />
        <h3 className="text-lg font-medium">No Active Player</h3>
        <p>Select a player from the queue to start</p>
      </div>
    </Card>
  );

  const formatCurrency = (val) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val}`;
  };

  return (
    <Card className="bg-white overflow-hidden shadow-lg border-0">
      <div className="p-6 md:p-8">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          {/* Player Image */}
          <div className="w-full md:w-1/3 aspect-[4/5] bg-gradient-to-b from-slate-100 to-slate-200 rounded-2xl overflow-hidden relative group">
            {player.image_url ? (
              <img 
                src={player.image_url} 
                alt={player.name}
                className="w-full h-full object-cover object-top mix-blend-multiply group-hover:scale-105 transition-transform duration-700" 
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-slate-300">
                <User className="w-24 h-24" />
              </div>
            )}
            <div className="absolute top-4 right-4">
               <Badge variant={status === 'active' ? "default" : "secondary"} className="uppercase tracking-wider">
                 {status}
               </Badge>
            </div>
          </div>

          {/* Player Details */}
          <div className="flex-1 w-full">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h2 className="text-4xl font-bold text-slate-900 mb-1">{player.name}</h2>
                <p className="text-slate-500 text-lg flex items-center gap-2">
                  {player.role} • {player.country}
                </p>
              </div>
            </div>

            <div className="mt-8 p-6 bg-slate-50 rounded-2xl border border-slate-100">
              <div className="text-center mb-2 text-slate-500 uppercase tracking-widest text-xs font-semibold">Current Price</div>
              <div className="text-center text-6xl font-black text-blue-600 tracking-tight">
                {formatCurrency(currentPrice || player.base_price)}
              </div>
              <div className="text-center mt-2 text-slate-400 text-sm">
                Base Price: {formatCurrency(player.base_price)}
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-4 mt-8">
              <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-sm text-center">
                <div className="text-xs text-slate-400 uppercase font-semibold mb-1">Matches</div>
                <div className="text-2xl font-bold text-slate-700">{player.stats?.matches || '-'}</div>
              </div>
              <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-sm text-center">
                <div className="text-xs text-slate-400 uppercase font-semibold mb-1">
                  {player.role.includes('Bowler') ? 'Wickets' : 'Runs'}
                </div>
                <div className="text-2xl font-bold text-slate-700">
                  {player.role.includes('Bowler') ? (player.stats?.wickets || '-') : (player.stats?.runs || '-')}
                </div>
              </div>
              <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-sm text-center">
                <div className="text-xs text-slate-400 uppercase font-semibold mb-1">
                  {player.role.includes('Bowler') ? 'Economy' : 'Average'}
                </div>
                <div className="text-2xl font-bold text-slate-700">
                  {player.role.includes('Bowler') ? (player.stats?.economy || '-') : (player.stats?.average || '-')}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {winner && (
          <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded-xl flex items-center justify-between">
            <span className="text-blue-700 font-medium">Current Leader</span>
            <div className="flex items-center gap-3">
              <span className="font-bold text-blue-900 text-lg">{winner.name}</span>
              {winner.logo_url && <img src={winner.logo_url} className="w-8 h-8 object-contain" alt="logo" />}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
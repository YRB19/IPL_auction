import React, { useState } from 'react';
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle2, XCircle, Loader2, Activity } from "lucide-react";

export default function SystemHealthCheck() {
  const [results, setResults] = useState(null);
  const [isRunning, setIsRunning] = useState(false);

  const runDiagnostics = async () => {
    setIsRunning(true);
    const report = {
      database: false,
      latency: 0,
      entities: {}
    };

    const start = Date.now();
    try {
      // Check DB Connectivity via Entity List
      await base44.entities.Team.list({ limit: 1 });
      report.database = true;
      
      // Check Entities
      const entities = ['Team', 'Player', 'Bid', 'AuctionState', 'ProxyBid'];
      for (const entity of entities) {
        try {
          await base44.entities[entity].list({ limit: 1 });
          report.entities[entity] = true;
        } catch (e) {
          report.entities[entity] = false;
        }
      }

      report.latency = Date.now() - start;
    } catch (e) {
      console.error(e);
    }

    setResults(report);
    setIsRunning(false);
  };

  return (
    <Card className="p-4 bg-slate-900 text-slate-100 mt-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold flex items-center gap-2">
          <Activity className="w-5 h-5 text-green-400" /> System Diagnostics
        </h3>
        <Button 
          size="sm" 
          variant="outline" 
          className="text-xs border-slate-700 hover:bg-slate-800 text-slate-300"
          onClick={runDiagnostics}
          disabled={isRunning}
        >
          {isRunning ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : 'Run Tests'}
        </Button>
      </div>

      {results && (
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span>Database Connection</span>
            {results.database ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
          </div>
          <div className="flex justify-between">
            <span>Latency</span>
            <span className={results.latency < 200 ? "text-green-400" : "text-yellow-400"}>{results.latency}ms</span>
          </div>
          <div className="h-px bg-slate-800 my-2" />
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(results.entities).map(([entity, status]) => (
              <div key={entity} className="flex justify-between items-center bg-slate-800 px-2 py-1 rounded">
                <span className="text-xs text-slate-400">{entity}</span>
                {status ? <span className="w-2 h-2 bg-green-500 rounded-full" /> : <span className="w-2 h-2 bg-red-500 rounded-full" />}
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}
import React from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X, UserCog } from "lucide-react";
import { toast } from "sonner";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";

export default function AccessRequests() {
    const queryClient = useQueryClient();

    const { data: requests, isLoading } = useQuery({
        queryKey: ['auctioneerRequests'],
        queryFn: () => base44.entities.AuctioneerRequest.filter({ status: 'pending' }, '-created_date'),
    });

    const processRequestMutation = useMutation({
        mutationFn: async ({ request, action }) => {
            // Note: We no longer promote to 'admin' role automatically. 
            // Access is granted based on the 'approved' status of this request.
            if (action === 'approve') {
                // Optional: You could still verify user exists if needed, but strictly not required for just updating the request status.
                // keeping it simple as requested.
            }

            // 3. Update Request Status
            await base44.entities.AuctioneerRequest.update(request.id, { 
                status: action === 'approve' ? 'approved' : 'rejected',
                reviewed_by: (await base44.auth.me()).email
            });
        },
        onSuccess: (_, { action, request }) => {
            queryClient.invalidateQueries({ queryKey: ['auctioneerRequests'] });
            if (action === 'approve') {
                toast.success(`Access granted to ${request.email}.`);
            } else {
                toast.success(`Request rejected for ${request.email}`);
            }
        },
        onError: (err) => toast.error(err.message)
    });

    if (isLoading) return null;

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button variant="outline" className="relative">
                    <UserCog className="w-4 h-4 mr-2" />
                    Access Requests
                    {requests?.length > 0 && (
                        <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center bg-red-500">
                            {requests.length}
                        </Badge>
                    )}
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Pending Auctioneer Requests</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                    {requests?.length === 0 && (
                        <p className="text-center text-slate-500 py-8">No pending requests.</p>
                    )}
                    {requests?.map(req => (
                        <div key={req.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border">
                            <div>
                                <div className="font-medium">{req.name || 'Unknown Name'}</div>
                                <div className="text-sm text-slate-500">{req.email}</div>
                                <div className="text-xs text-slate-400 mt-1">
                                    Requested: {new Date(req.created_date).toLocaleDateString()}
                                </div>
                            </div>
                            <div className="flex gap-2">
                                <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="text-red-600 border-red-200 hover:bg-red-50"
                                    onClick={() => processRequestMutation.mutate({ request: req, action: 'reject' })}
                                    disabled={processRequestMutation.isPending}
                                >
                                    <X className="w-4 h-4" />
                                </Button>
                                <Button 
                                    size="sm" 
                                    className="bg-green-600 hover:bg-green-700"
                                    onClick={() => processRequestMutation.mutate({ request: req, action: 'approve' })}
                                    disabled={processRequestMutation.isPending}
                                >
                                    <Check className="w-4 h-4 mr-2" /> Approve
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            </DialogContent>
        </Dialog>
    );
}
import React, { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';

export default function Timer({ endsAt, totalSeconds = 60, onExpire, status }) {
  const [timeLeft, setTimeLeft] = useState(totalSeconds);

  useEffect(() => {
    if (status !== 'active' || !endsAt) {
        // If paused or idle, we might show 00:00 or the remaining time if we had that state
        // For simplicity, if idle, show totalSeconds.
        if (status === 'idle') setTimeLeft(totalSeconds);
        return;
    }

    const interval = setInterval(() => {
      const now = Date.now();
      const diff = Math.ceil((endsAt - now) / 1000);
      
      if (diff <= 0) {
        setTimeLeft(0);
        clearInterval(interval);
        if (onExpire) onExpire();
      } else {
        setTimeLeft(diff);
      }
    }, 100); // Update frequently for smoothness

    return () => clearInterval(interval);
  }, [endsAt, status, onExpire, totalSeconds]);

  const formatTime = (s) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`flex items-center justify-center gap-4 text-6xl font-black tracking-widest ${timeLeft <= 10 && status === 'active' ? 'text-red-600 animate-pulse' : 'text-slate-700'}`}>
        <Clock className="w-12 h-12 text-slate-400" />
        {formatTime(timeLeft)}
    </div>
  );
}
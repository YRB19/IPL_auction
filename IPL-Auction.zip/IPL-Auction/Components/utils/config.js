export const APP_CONFIG = {
  MIN_BID_INCREMENT_LOW: 500000,   // 5L
  MIN_BID_INCREMENT_MID: 1000000,  // 10L
  MIN_BID_INCREMENT_HIGH: 2000000, // 20L
  
  RATE_LIMIT_BIDS_PER_SECOND: 3,
  RATE_LIMIT_WINDOW_MS: 1000,
  
  AUCTION_TIMER_DEFAULT: 60,
  AUCTION_TIMER_EXTEND: 30,
};

export const checkRateLimit = (lastActionTime) => {
  const now = Date.now();
  if (now - lastActionTime < (APP_CONFIG.RATE_LIMIT_WINDOW_MS / APP_CONFIG.RATE_LIMIT_BIDS_PER_SECOND)) {
    return false;
  }
  return true;
};
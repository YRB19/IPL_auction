import React, { useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Wallet, AlertCircle, TrendingUp, Wifi, Zap, Activity, History } from 'lucide-react';
import PlayerCard from '@/components/auction/PlayerCard';
import Timer from '@/components/auction/Timer';
import { APP_CONFIG, checkRateLimit } from '@/components/utils/config';
// Verified imports
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function TeamDashboard() {
  const [myTeamId, setMyTeamId] = useState('');
  const [proxyAmount, setProxyAmount] = useState('');
  const [isProxyDialogOpen, setIsProxyDialogOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [authChecking, setAuthChecking] = useState(true);
  const queryClient = useQueryClient();
  const prevAuctionStateRef = React.useRef(null);
  const lastBidTimeRef = React.useRef(0);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setAuthChecking(false);
      if (!u) base44.auth.redirectToLogin();
    }).catch(() => {
      setAuthChecking(false);
      base44.auth.redirectToLogin();
    });
  }, []);

  // --- Queries ---
  const { data: teams, isLoading: teamsLoading } = useQuery({
    queryKey: ['teams'],
    queryFn: () => base44.entities.Team.list(),
  });

  useEffect(() => {
      if (user && teams) {
          const myTeam = teams.find(t => t.owner_email === user.email);
          if (myTeam) setMyTeamId(myTeam.id);
      }
  }, [user, teams]);

  const { data: auctionState } = useQuery({
    queryKey: ['auctionState'],
    queryFn: async () => {
       const res = await base44.entities.AuctionState.list();
       return res[0];
    },
    refetchInterval: 1000,
  });

  const { data: activePlayer } = useQuery({
    queryKey: ['activePlayer', auctionState?.active_player_id],
    queryFn: () => auctionState?.active_player_id ? base44.entities.Player.get(auctionState.active_player_id) : null,
    enabled: !!auctionState?.active_player_id,
  });

  const { data: myTeam } = useQuery({
    queryKey: ['team', myTeamId],
    queryFn: () => base44.entities.Team.get(myTeamId),
    enabled: !!myTeamId,
    refetchInterval: 2000, // Keep budget synced
  });

  const { data: recentBids } = useQuery({
    queryKey: ['recentBids', auctionState?.active_player_id],
    queryFn: () => base44.entities.Bid.filter({ player_id: auctionState?.active_player_id }, '-created_date', 5),
    enabled: !!auctionState?.active_player_id,
    refetchInterval: 1000,
  });

  // --- Phase 9: Presence / Heartbeat ---
  useEffect(() => {
      if (!myTeamId) return;
      const interval = setInterval(() => {
          base44.entities.Team.update(myTeamId, { last_seen: Date.now() });
      }, 5000); // Heartbeat every 5s
      return () => clearInterval(interval);
  }, [myTeamId]);

  // --- Phase 8: Notifications ---
  useEffect(() => {
      if (!auctionState || !myTeamId) return;
      const prev = prevAuctionStateRef.current;
      
      if (prev) {
          // Outbid Notification
          if (prev.current_winner_team_id === myTeamId && 
              auctionState.current_winner_team_id !== myTeamId && 
              auctionState.status === 'active') {
              toast.error("⚠️ You have been outbid!", { duration: 3000 });
          }
          // Auction Start
          if (prev.status === 'idle' && auctionState.status === 'active') {
              toast.info("Auction Started!");
          }
          // Sold
          if (prev.status === 'active' && auctionState.status === 'sold') {
              if (auctionState.current_winner_team_id === myTeamId) {
                  toast.success("🎉 You won the player!");
              } else {
                  toast.info("Player Sold.");
              }
          }
      }
      prevAuctionStateRef.current = auctionState;
  }, [auctionState, myTeamId]);

  // --- Bid Logic (Phase 10 & 11) ---
  const placeBidMutation = useMutation({
    // Phase 10: Optimistic Updates
    onMutate: async (increment) => {
        if (!checkRateLimit(lastBidTimeRef.current)) {
            throw new Error("Please wait a moment before bidding again.");
        }
        lastBidTimeRef.current = Date.now();

        // Cancel outgoing refetches
        await queryClient.cancelQueries({ queryKey: ['auctionState'] });

        // Snapshot previous values
        const previousState = queryClient.getQueryData(['auctionState']);
        const previousBids = queryClient.getQueryData(['recentBids', auctionState?.active_player_id]);

        // Optimistically update price
        const nextPrice = (previousState?.current_price || activePlayer?.base_price) + increment;
        
        if (myTeam && nextPrice > myTeam.remaining_budget) {
             throw new Error(`Insufficient funds! Required: ₹${(nextPrice/10000000).toFixed(2)} Cr`);
        }

        queryClient.setQueryData(['auctionState'], old => ({
            ...old,
            current_price: nextPrice,
            current_winner_team_id: myTeamId,
        }));

        // Optimistically add bid row
        const optimisticBid = {
            id: 'temp-' + Date.now(),
            player_id: activePlayer?.id,
            team_id: myTeamId,
            team_name: myTeam.name,
            amount: nextPrice,
            created_date: new Date().toISOString(),
            is_optimistic: true
        };

        queryClient.setQueryData(['recentBids', auctionState?.active_player_id], old => {
            return [optimisticBid, ...(old || [])].slice(0, 5);
        });

        return { previousState, previousBids };
    },
    mutationFn: async (increment) => {
        // Actual Server Call
        const nextBid = (auctionState.current_price || activePlayer.base_price) + increment;
        
        await base44.entities.Bid.create({
            player_id: activePlayer.id,
            team_id: myTeam.id,
            team_name: myTeam.name,
            amount: nextBid,
            is_auto_bid: false
        });

        const endsAt = Date.now() + (APP_CONFIG.AUCTION_TIMER_EXTEND * 1000); 
        await base44.entities.AuctionState.update(auctionState.id, {
            current_price: nextBid,
            current_winner_team_id: myTeam.id,
            timer_ends_at: endsAt
        });
    },
    onSuccess: () => {
        toast.success("Bid Placed!");
    },
    onError: (err, variables, context) => {
        // Rollback
        if (context?.previousState) {
            queryClient.setQueryData(['auctionState'], context.previousState);
        }
        if (context?.previousBids) {
            queryClient.setQueryData(['recentBids', auctionState?.active_player_id], context.previousBids);
        }
        
        // Audit Log for Rate Limit
        if (err.message.includes("wait a moment")) {
             base44.entities.AuditLog.create({
                 event_type: 'rate_limit_violation',
                 description: `Rate limit hit by team ${myTeam.name}`,
                 team_id: myTeamId,
                 severity: 'warning'
             });
        }

        toast.error(err.message);
    },
    onSettled: () => {
        queryClient.invalidateQueries({ queryKey: ['auctionState'] });
        queryClient.invalidateQueries({ queryKey: ['recentBids'] });
    }
  });

  // --- Phase 6: Proxy Bid Mutation ---
  const setProxyBidMutation = useMutation({
      mutationFn: async (amount) => {
          if (!activePlayer) return;
          // Check if proxy exists, else create
          const existing = await base44.entities.ProxyBid.filter({ team_id: myTeamId, player_id: activePlayer.id });
          
          if (existing.length > 0) {
              await base44.entities.ProxyBid.update(existing[0].id, {
                  max_amount: Number(amount),
                  is_active: true
              });
          } else {
              await base44.entities.ProxyBid.create({
                  team_id: myTeamId,
                  player_id: activePlayer.id,
                  max_amount: Number(amount),
                  is_active: true
              });
          }
      },
      onSuccess: () => {
          toast.success("Auto Bid Limit Set");
          setIsProxyDialogOpen(false);
      }
  });

  const currentWinner = teams?.find(t => t.id === auctionState?.current_winner_team_id);
  const isWinning = currentWinner?.id === myTeamId;

  const getMinIncrement = (currentPrice) => {
      if (currentPrice < 10000000) return 500000; // 5L
      if (currentPrice < 20000000) return 1000000; // 10L
      return 2000000; // 20L
  };

  const minIncrement = getMinIncrement(auctionState?.current_price || 0);

  if (authChecking || teamsLoading) return <div className="flex items-center justify-center h-screen">Loading...</div>;

  if (!myTeamId) {
      return (
          <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
              <Card className="w-full max-w-md p-8 text-center space-y-6">
                  <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
                  <p className="text-slate-500">
                      No team is associated with your email address ({user?.email}).
                      Please contact the administrator to assign a team to your account.
                  </p>
                  <Button variant="outline" onClick={() => base44.auth.logout()}>Logout</Button>
              </Card>
          </div>
      );
  }

  // Wait for myTeam data to load
  if (!myTeam) return <div className="flex items-center justify-center h-screen">Loading Team Data...</div>;

  return (
    <div className="min-h-screen bg-slate-50 pb-20 md:pb-0">
      {/* Top Bar */}
      <div className="bg-white border-b px-4 py-3 flex justify-between items-center sticky top-0 z-50 shadow-sm">
         <div className="flex items-center gap-3">
             <div className="w-8 h-8 rounded-full overflow-hidden border">
                 {myTeam.logo_url && <img src={myTeam.logo_url} alt="" className="w-full h-full object-contain" />}
             </div>
             <span className="font-bold text-slate-800 hidden md:inline">{myTeam.name}</span>
             <span className="font-bold text-slate-800 md:hidden">{myTeam.acronym}</span>
         </div>
         <div className="flex items-center gap-4">
             <div className="flex flex-col items-end">
                 <span className="text-xs text-slate-500 uppercase font-semibold">Purse Remaining</span>
                 <span className="font-bold text-emerald-600">₹{(myTeam.remaining_budget / 10000000).toFixed(2)} Cr</span>
             </div>
             <div className="h-8 w-px bg-slate-200"></div>
             <div className="flex items-center gap-2 text-green-600 text-xs font-medium">
                 <Wifi className="w-4 h-4" /> Connected
             </div>
         </div>
      </div>

      <div className="max-w-5xl mx-auto p-4 space-y-6">
         {/* Main Auction Area */}
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div>
                <PlayerCard 
                    player={activePlayer}
                    currentPrice={auctionState?.current_price}
                    winner={currentWinner}
                    status={auctionState?.status}
                />
             </div>

             <div className="flex flex-col gap-4">
                 {/* Timer & Status */}
                 <Card className="p-6 flex flex-col items-center justify-center bg-white border-slate-200 shadow-sm min-h-[200px]">
                    {auctionState?.status === 'active' ? (
                        <>
                             <Timer 
                                endsAt={auctionState.timer_ends_at} 
                                status={auctionState.status} 
                            />
                            <div className="mt-4 text-sm text-slate-500 uppercase tracking-widest font-semibold">Time Remaining</div>
                        </>
                    ) : (
                        <div className="text-center text-slate-400">
                            <AlertCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                            <p>{auctionState?.status === 'idle' ? 'Waiting for next player...' : 'Auction Paused'}</p>
                        </div>
                    )}
                 </Card>

                 {/* Bidding Controls */}
                 <Card className={`p-6 border-2 transition-colors ${isWinning ? 'border-green-500 bg-green-50' : 'border-blue-100 bg-white'}`}>
                    {auctionState.status === 'sold' ? (
                        <div className="text-center py-8">
                             {isWinning ? (
                                 <>
                                    <div className="text-5xl mb-4">🎉</div>
                                    <div className="text-2xl font-bold text-green-700 mb-2">CONGRATULATIONS!</div>
                                    <p className="text-green-600">You bought {activePlayer?.name} for ₹{(auctionState.current_price/10000000).toFixed(2)} Cr</p>
                                 </>
                             ) : (
                                 <>
                                    <div className="text-xl font-bold text-slate-700 mb-2">SOLD</div>
                                    <p className="text-slate-500">Sold to {currentWinner?.name} for ₹{(auctionState.current_price/10000000).toFixed(2)} Cr</p>
                                 </>
                             )}
                        </div>
                    ) : auctionState.status === 'unsold' ? (
                        <div className="text-center py-8">
                            <div className="text-xl font-bold text-slate-400">UNSOLD</div>
                        </div>
                    ) : isWinning ? (
                        <div className="text-center py-4">
                            <div className="text-green-600 font-bold text-xl mb-2">You are winning!</div>
                            <p className="text-green-800">Current Bid: ₹{(auctionState.current_price/100000).toFixed(2)} L</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <div className="text-center text-sm text-slate-500">
                                Min Increment: ₹{(minIncrement/100000).toFixed(1)} L
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <Button 
                                    size="lg"
                                    className="w-full bg-blue-600 hover:bg-blue-700 h-16 text-lg"
                                    disabled={auctionState?.status !== 'active' || placeBidMutation.isPending}
                                    onClick={() => placeBidMutation.mutate(minIncrement)}
                                >
                                    {placeBidMutation.isPending ? '...' : `+ ₹${(minIncrement/100000).toFixed(0)}L`}
                                </Button>
                                <Button 
                                    size="lg"
                                    className="w-full bg-indigo-600 hover:bg-indigo-700 h-16 text-lg"
                                    disabled={auctionState?.status !== 'active' || placeBidMutation.isPending}
                                    onClick={() => placeBidMutation.mutate(minIncrement * 2)}
                                >
                                    {placeBidMutation.isPending ? '...' : `+ ₹${(minIncrement * 2 / 100000).toFixed(0)}L`}
                                </Button>
                            </div>
                            <Button 
                                variant="outline"
                                className="w-full"
                                disabled={auctionState?.status !== 'active' || placeBidMutation.isPending}
                                onClick={() => placeBidMutation.mutate(10000000)} // +1 Cr
                            >
                                <TrendingUp className="w-4 h-4 mr-2" /> Jump +1 Cr
                            </Button>

                            <Dialog open={isProxyDialogOpen} onOpenChange={setIsProxyDialogOpen}>
                                <DialogTrigger asChild>
                                    <Button variant="secondary" className="w-full text-slate-600" disabled={auctionState?.status !== 'active'}>
                                        <Zap className="w-4 h-4 mr-2 text-amber-500" /> Set Auto-Bid Limit
                                    </Button>
                                </DialogTrigger>
                                <DialogContent>
                                    <DialogHeader>
                                        <DialogTitle>Set Auto-Bid Limit</DialogTitle>
                                    </DialogHeader>
                                    <div className="space-y-4 py-4">
                                        <div className="space-y-2">
                                            <Label>Max Amount (₹)</Label>
                                            <Input 
                                                type="number" 
                                                placeholder="Enter max limit" 
                                                value={proxyAmount}
                                                onChange={(e) => setProxyAmount(e.target.value)}
                                            />
                                            <p className="text-xs text-slate-500">
                                                System will auto-bid for you up to this amount.
                                            </p>
                                        </div>
                                        <Button 
                                            className="w-full"
                                            onClick={() => setProxyBidMutation.mutate(proxyAmount)}
                                        >
                                            Set Limit
                                        </Button>
                                    </div>
                                </DialogContent>
                            </Dialog>
                            </div>
                            )}
                            </Card>

                            {/* Recent Bids (Optimistic) */}
                            <Card className="p-4 bg-white shadow-sm">
                                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                                    <History className="w-4 h-4" /> Recent Bids
                                </h3>
                                <div className="space-y-2">
                                    {recentBids?.map(bid => (
                                        <div key={bid.id} className={`flex justify-between items-center text-sm p-2 rounded ${bid.is_optimistic ? 'bg-blue-50 animate-pulse' : 'hover:bg-slate-50'}`}>
                                            <div className="flex flex-col">
                                                <span className="font-medium text-slate-700">{bid.team_name}</span>
                                                <span className="text-[10px] text-slate-400">
                                                    {bid.is_optimistic ? 'Sending...' : new Date(bid.created_date).toLocaleTimeString()}
                                                </span>
                                            </div>
                                            <span className="font-bold text-slate-600">₹{(bid.amount / 100000).toFixed(2)} L</span>
                                        </div>
                                    ))}
                                    {(!recentBids || recentBids.length === 0) && <div className="text-center text-slate-400 text-sm py-4">No bids yet</div>}
                                </div>
                            </Card>
             </div>
         </div>
      </div>
    </div>
  );
}
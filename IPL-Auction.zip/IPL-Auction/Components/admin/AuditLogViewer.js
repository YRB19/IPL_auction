import React from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText, AlertTriangle, Info, ShieldAlert } from 'lucide-react';

export default function AuditLogViewer() {
  const { data: logs, refetch } = useQuery({
    queryKey: ['auditLogs'],
    queryFn: () => base44.entities.AuditLog.list({
        sort: { created_date: -1 },
        limit: 50
    }),
    enabled: false // Only fetch when opened
  });

  return (
    <Dialog onOpenChange={(open) => open && refetch()}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <ShieldAlert className="w-4 h-4" /> Audit Logs
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>System Audit Logs</DialogTitle>
        </DialogHeader>
        <ScrollArea className="flex-1 mt-4 pr-4">
          <div className="space-y-2">
            {logs?.map(log => (
              <div key={log.id} className="flex gap-3 p-3 rounded bg-slate-50 border text-sm">
                <div className="mt-0.5">
                  {log.severity === 'warning' ? <AlertTriangle className="w-4 h-4 text-amber-500" /> :
                   log.severity === 'error' ? <ShieldAlert className="w-4 h-4 text-red-500" /> :
                   <Info className="w-4 h-4 text-blue-500" />}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-700">{log.event_type}</span>
                    <span className="text-xs text-slate-400">{new Date(log.created_date).toLocaleString()}</span>
                  </div>
                  <p className="text-slate-600 mt-1">{log.description}</p>
                  {log.team_id && <div className="text-xs text-slate-400 mt-1">Team ID: {log.team_id}</div>}
                </div>
              </div>
            ))}
            {(!logs || logs.length === 0) && <div className="text-center text-slate-400 py-8">No logs recorded</div>}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

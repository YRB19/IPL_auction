import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Gavel, Users, Monitor, ArrowRight } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4 font-sans">
      <div className="max-w-5xl w-full text-center mb-16">
        <div className="inline-flex items-center justify-center p-3 bg-blue-600 rounded-xl mb-6 shadow-lg">
          <Gavel className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-5xl font-extrabold text-gray-900 mb-4 tracking-tight">
          IPL Auction Platform
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Professional-grade auction management with live bidding, proxy bids, and comprehensive admin controls.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full px-4">
        {/* Auctioneer Dashboard */}
        <Link 
          to={createPageUrl('AuctioneerDashboard')}
          className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 p-8 border border-gray-200 hover:border-blue-500 flex flex-col items-center text-center"
        >
          <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-6 group-hover:bg-blue-600 transition-colors duration-300">
            <Gavel className="w-8 h-8 text-blue-600 group-hover:text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Auctioneer Dashboard</h2>
          <p className="text-gray-500 mb-8 text-sm leading-relaxed">
            Complete control over auction flow. Start/Stop auctions, manage timer, and force sell players.
          </p>
          <div className="mt-auto flex items-center text-blue-600 font-semibold group-hover:translate-x-1 transition-transform">
            Launch Dashboard <ArrowRight className="w-4 h-4 ml-2" />
          </div>
        </Link>

        {/* Team Bidder UI */}
        <Link 
          to={createPageUrl('TeamDashboard')}
          className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 p-8 border border-gray-200 hover:border-green-500 flex flex-col items-center text-center"
        >
          <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mb-6 group-hover:bg-green-600 transition-colors duration-300">
            <Users className="w-8 h-8 text-green-600 group-hover:text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Team Bidder UI</h2>
          <p className="text-gray-500 mb-8 text-sm leading-relaxed">
            Intuitive interface for teams. Real-time updates, one-click bidding, and budget tracking.
          </p>
          <div className="mt-auto flex items-center text-green-600 font-semibold group-hover:translate-x-1 transition-transform">
            Enter Auction Room <ArrowRight className="w-4 h-4 ml-2" />
          </div>
        </Link>

        {/* Public Display */}
        <Link 
          to={createPageUrl('PublicDisplay')}
          className="group bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 p-8 border border-gray-200 hover:border-purple-500 flex flex-col items-center text-center"
        >
          <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mb-6 group-hover:bg-purple-600 transition-colors duration-300">
            <Monitor className="w-8 h-8 text-purple-600 group-hover:text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">Public Display</h2>
          <p className="text-gray-500 mb-8 text-sm leading-relaxed">
            Large-screen optimized view for audience viewing. Live bid stream and player stats.
          </p>
          <div className="mt-auto flex items-center text-purple-600 font-semibold group-hover:translate-x-1 transition-transform">
            Open Display <ArrowRight className="w-4 h-4 ml-2" />
          </div>
        </Link>
      </div>

      <div className="mt-24 text-gray-400 text-sm">
        Base44 Auction Platform v1.0 • Built for Performance
      </div>
    </div>
  );
}